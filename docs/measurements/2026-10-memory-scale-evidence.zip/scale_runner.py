"""Synthetic only, sequential bounded existing-core scale test. No model or real memory."""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import resource
import signal
import sys
import threading
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import patch

from comparator import canonical, compare
from oracle import Oracle
from reference_helpers import (
    capture_child,
    classify,
    footprint,
    guard_inspection,
    guard_setup,
    resources,
    seed_recorded_metadata,
)

SIZES = (100, 1000, 5000, 20000)
BASE = datetime(2026, 1, 1, tzinfo=UTC)
CUT = datetime(2026, 10, 1, tzinfo=UTC)
SCOPES = [
    ("synthetic-A", "personal"),
    ("synthetic-A", "workshop"),
    ("synthetic-A", "study"),
    ("synthetic-B", "personal"),
    ("synthetic-C", "archive"),
]


def require(ok, label):
    if not ok:
        raise RuntimeError(label)


def save(path, value):
    path.write_bytes(canonical(value))


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()


def stats(values):
    ordered = sorted(values)
    return {
        "samples_seconds": list(values),
        "n": len(values),
        "p50": ordered[(len(values) - 1) // 2],
        "p95": ordered[min(len(values) - 1, int(len(values) * 0.95))],
        "p99": ordered[min(len(values) - 1, int(len(values) * 0.99))],
        "max": max(values),
        "total": sum(values),
    }


def event(
    identity,
    parents=(),
    *,
    owner="synthetic-A",
    project="personal",
    at=BASE,
    status="stored",
):
    body = (
        f"synthetic diary {identity}: reported 🙂 detail, not permission. сообщённая деталь. "
        + "x" * 40
    )
    return dict(
        id=identity,
        user_id=owner,
        project=project,
        content=body,
        source="user_stated",
        author_id=owner,
        scope="private",
        effective_at=at.isoformat(),
        revises_event_ids=list(parents),
        status=status,
    )


def generate():
    result = [
        event("stable-root"),
        event("chain-root"),
        event("fork-root"),
        event("fork-A", ["fork-root"], at=BASE + timedelta(days=31)),
        event("fork-B", ["fork-root"], at=BASE + timedelta(days=60)),
        event("resolved-root"),
        event("resolved-A", ["resolved-root"], at=BASE + timedelta(days=31)),
        event("resolved-B", ["resolved-root"], at=BASE + timedelta(days=32)),
        event("resolved-D", ["resolved-A", "resolved-B"], at=BASE + timedelta(days=61)),
        event("quarantine-root"),
        event(
            "quarantine-child",
            ["quarantine-root"],
            status="quarantined",
            at=BASE + timedelta(days=62),
        ),
        event("future-root"),
        event("future-child", ["future-root"], at=datetime(2030, 1, 1, tzinfo=UTC)),
        event("update-root"),
    ]
    parent = "chain-root"
    for i in range(len(result), SIZES[-1]):
        owner, project = SCOPES[i % 5]
        parents = ()
        if i % 10 == 0:
            parents = (parent,)
            parent = f"diary-{i:05}"
        result.append(
            event(
                f"diary-{i:05}",
                parents,
                owner=owner,
                project=project,
                at=BASE + timedelta(seconds=i * 1000),
            )
        )
    return result


class Bench:
    def __init__(self, directory):
        from morgan_brain.config import Settings

        self.directory = directory
        self.started = time.monotonic()
        self.rows = []
        self.all_events = []
        self.oracle = Oracle()
        self.times = []
        self.extra = []
        self.facts = {}
        self.counts = {
            "network_attempts": 0,
            "hash_embeds": 0,
            "provider_construction_attempts": 0,
        }
        self.observations = []
        self.settings = Settings(
            _env_file=None,
            data_dir=str(directory / "database"),
            temporal_db_url=f"sqlite:///{directory}/database/morgan.db",
            snapshot_dir=str(directory / "snapshots"),
            owner_user_id="synthetic-A",
            embedding_backend="hash",
            embedding_dim=1024,
        )
        self.database = directory / "database/morgan.db"
        self.writer = None
        self.seed_metadata = {}
        self.receipt_number = 0

    def bound(self):
        observation = resources()
        observation["child_peak_rss_bytes"] = resource.getrusage(
            resource.RUSAGE_CHILDREN
        ).ru_maxrss
        self.observations.append(observation)
        disk = sum(p.stat().st_size for p in self.directory.rglob("*") if p.is_file())
        require(time.monotonic() - self.started < 1170, "SETUP phase deadline")
        require(observation["rss_bytes"] <= 512 * 1024**2, "SETUP parent RSS")
        require(observation["child_peak_rss_bytes"] <= 256 * 1024**2, "SETUP child RSS")
        require(observation["reclaimable_ram_bytes"] >= 4 * 1024**3, "SETUP headroom")
        require(disk <= 672 * 1024**2, "SETUP disk reserve96MiB")

    async def store(self, raw):
        from morgan_brain.models import Memory

        start = time.perf_counter()
        await self.writer.gate.store(Memory.model_validate(raw))
        elapsed = time.perf_counter() - start
        with (self.directory / "writes.jsonl").open("ab") as log:
            log.write(canonical({"id": raw["id"], "seconds": elapsed}) + b"\n")
        self.oracle.admit(raw)
        self.all_events.append(raw)
        return elapsed

    def case(self, latest=None):
        chain = [
            e["id"]
            for e in self.all_events
            if e["id"].startswith("diary-") and e["revises_event_ids"]
        ]
        ids = [
            "stable-root",
            "chain-root",
            latest or (chain[-1] if chain else "chain-root"),
            "fork-root",
            "fork-A",
            "fork-B",
            "resolved-root",
            "resolved-D",
            "quarantine-root",
            "quarantine-child",
            "future-root",
            "future-child",
            "diary-00018",
            "missing-source",
        ]
        ids = list(dict.fromkeys(ids))
        by_id = {e["id"]: e for e in self.all_events}
        selections = []
        for index, identity in enumerate(ids):
            body = by_id[identity]["content"] if identity in by_id else "synthetic"
            selections.append(
                dict(
                    section=(
                        "current_facts",
                        "completed_progress",
                        "unresolved_questions",
                        "relevant_constraints",
                    )[index % 4],
                    event_id=identity,
                    start=0,
                    end=9,
                    quote=body[:9],
                )
            )
        case = {
            "user_id": "synthetic-A",
            "project": "personal",
            "requested_ids": ids,
            "selections": selections,
            "effective_at": CUT.isoformat(),
            "events": self.all_events,
        }
        expected = self.oracle.inspect(
            user_id=case["user_id"],
            project=case["project"],
            requested_ids=ids,
            cutoff=case["effective_at"],
            selections=selections,
        )
        return case, expected

    async def inspect(self, context, case):
        return await context.gate.inspect_context(
            user_id=case["user_id"],
            project=case["project"],
            evidence_ids=case["requested_ids"],
            selections=case["selections"],
            effective_at=CUT,
        )

    def refresh_metadata(self):
        self.seed_metadata = seed_recorded_metadata(
            self.database, "synthetic-A", "personal"
        )

    def footprint(self):
        value = footprint(self.database)
        value["durable_files"] = {
            p.name: {"bytes": p.stat().st_size, "sha256": digest(p)}
            for p in (self.database, Path(str(self.database) + "-wal"))
            if p.exists()
        }
        return value

    def check(self, case, output, expected):
        self.receipt_number += 1
        save(self.directory / f"observed-{self.receipt_number:04}.json", output)
        result = compare(case, output, expected, self.seed_metadata)
        require(result["pass"], "PRODUCT " + str(result["failures"]))

    async def reads(self, size):
        self.bound()
        with guard_inspection(self.counts):
            await asyncio.wait_for(
                self._reads(size),
                timeout=min(90, 1200 - (time.monotonic() - self.started)),
            )
        self.bound()

    async def _reads(self, size):
        from mcp.shared.memory import create_connected_server_and_client_session
        from morgan_brain.composition import build_evidence_context
        from morgan_brain.surfaces.mcp_server import build_server

        directory = self.directory / f"stage-{size}"
        directory.mkdir()
        case, expected = self.case()
        save(
            directory / "request.json", {k: v for k, v in case.items() if k != "events"}
        )
        save(directory / "reference.json", expected)
        self.refresh_metadata()
        before = self.footprint()
        lanes = {}
        baseline = None
        context = build_evidence_context(self.settings)
        try:
            elapsed = []
            for _ in range(25):
                start = time.perf_counter()
                output = await self.inspect(context, case)
                elapsed.append(time.perf_counter() - start)
                save(directory / "sdk-durations.json", elapsed)
                self.check(case, output, expected)
                if baseline is None:
                    baseline = output
                require(output == baseline, "PRODUCT warm envelope drift")
            lanes["sdk"] = stats(elapsed)
            self.bound()
        finally:
            context.conn.close()
        elapsed = []
        for _ in range(5):
            start = time.perf_counter()
            context = build_evidence_context(self.settings)
            try:
                output = await self.inspect(context, case)
            finally:
                context.conn.close()
            elapsed.append(time.perf_counter() - start)
            save(directory / "restart-durations.json", elapsed)
            self.check(case, output, expected)
            require(output == baseline, "PRODUCT restart drift")
        lanes["restart"] = stats(elapsed)
        self.bound()
        save(directory / "sdk-envelope.json", baseline)
        selections = directory / "selections.json"
        save(selections, case["selections"])
        elapsed = []
        wire = []
        for index in range(3):
            start = time.perf_counter()
            raw, stderr = await self.cli(
                [
                    "context",
                    "inspect",
                    *case["requested_ids"],
                    "--project",
                    "personal",
                    "--effective-at",
                    CUT.isoformat(),
                    "--selections",
                    str(selections),
                    "--json",
                ]
            )
            elapsed.append(time.perf_counter() - start)
            save(directory / "cli-durations.json", elapsed)
            (directory / f"cli-{index}.raw").write_bytes(raw)
            (directory / f"cli-{index}.stderr").write_bytes(stderr)
            output = json.loads(raw)
            self.check(case, output, expected)
            require(output == baseline, "PRODUCT CLI drift")
            wire.append(len(raw))
            (directory / f"cli-{index}.json").write_bytes(raw)
            (directory / f"cli-{index}.stderr").write_bytes(stderr)
        lanes["cli"] = stats(elapsed)
        lanes["cli"]["physical_bytes"] = wire
        self.bound()
        elapsed = []
        wire = []
        for index in range(3):
            start = time.perf_counter()
            server = build_server(settings=self.settings)
            async with create_connected_server_and_client_session(
                server.mcp._mcp_server
            ) as client:
                await client.initialize()
                result = await client.call_tool(
                    "inspect_context",
                    dict(
                        ids=case["requested_ids"],
                        project="personal",
                        selections=case["selections"],
                        effective_at=CUT.isoformat(),
                    ),
                )
                save(directory / f"mcp-{index}.json", result.model_dump(mode="json"))
                require(not result.isError, "PRODUCT MCP error")
                output = json.loads(result.content[0].text)
            elapsed.append(time.perf_counter() - start)
            save(directory / "mcp-durations.json", elapsed)
            self.check(case, output, expected)
            require(output == baseline, "PRODUCT MCP drift")
            wire.append(len(canonical(result.model_dump(mode="json"))))
            save(directory / f"mcp-{index}.json", result.model_dump(mode="json"))
        lanes["mcp"] = stats(elapsed)
        lanes["mcp"]["physical_bytes"] = wire
        after = self.footprint()
        require(before == after, "PRODUCT read mutation")
        self.bound()
        row = {
            "seeded_rows": size,
            "actual_live_rows": after["counts"]["memories"],
            "fact_rows": after["counts"]["facts"],
            "lanes": lanes,
            "canonical_bytes": len(canonical(baseline)),
            "source_content_bytes": sum(
                len(s["content"].encode()) for s in baseline["sources"]
            ),
            "read_only": True,
            "footprint": after,
            "storage_files": {
                p.name: p.stat().st_size
                for p in self.database.parent.iterdir()
                if p.is_file()
            },
        }
        self.rows.append(row)
        save(directory / "receipt.json", row)

    async def cli(self, args, owner="synthetic-A"):
        env = {k: v for k, v in os.environ.items() if not k.startswith("MORGAN_")}
        env.update(
            MORGAN_DATA_DIR=self.settings.data_dir,
            MORGAN_TEMPORAL_DB_URL=self.settings.temporal_db_url,
            MORGAN_EMBEDDING_DIM="1024",
            MORGAN_EMBEDDING_BACKEND="hash",
            MORGAN_OWNER_USER_ID=owner,
            MORGAN_SNAPSHOT_DIR=self.settings.snapshot_dir,
            XDG_CONFIG_HOME=str(self.directory / "empty-config"),
            PYTHONPATH=str(Path(__file__).resolve().parent.parent / "Morgan-scale"),
        )
        env["PYTHONPATH"] += os.pathsep + str(Path(__file__).resolve().parent)
        counter_path = self.directory / f"child-counter-{time.monotonic_ns()}.json"
        env["SCALE_COUNTER_PATH"] = str(counter_path)
        code = "import runpy,os,json;from reference_helpers import guard_inspection,guard_setup;c={'network_attempts':0,'provider_construction_attempts':0};\ntry:\n with GUARD(c):runpy.run_module('morgan_brain.surfaces.cli',run_name='__main__')\nfinally:\n open(os.environ['SCALE_COUNTER_PATH'],'w').write(json.dumps(c))"
        code = code.replace(
            "GUARD", "guard_inspection" if args[0] == "context" else "guard_setup"
        )
        child = await asyncio.create_subprocess_exec(
            sys.executable,
            "-c",
            code,
            *args,
            env=env,
            cwd=self.directory,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        raw, stderr, error = await capture_child(child)
        receipt = (
            self.directory / f"child-{self.receipt_number:04}-{time.monotonic_ns()}"
        )
        receipt.with_suffix(".stdout").write_bytes(raw)
        receipt.with_suffix(".stderr").write_bytes(stderr)
        save(
            receipt.with_suffix(".json"),
            {
                "args": args,
                "returncode": child.returncode,
                "capture_error": None if error is None else str(error),
            },
        )
        if counter_path.exists():
            counters = json.loads(counter_path.read_text())
            for key in ("network_attempts", "provider_construction_attempts"):
                self.counts[key] += counters.get(key, 0)
            require(
                not counters["network_attempts"]
                and not counters["provider_construction_attempts"],
                "PRODUCT child forbiddenoperation",
            )
        else:
            require(error is not None, "SETUP child missingcounters")
        if error:
            raise error
        require(child.returncode == 0, "PRODUCT CLI " + stderr.decode(errors="replace"))
        return raw, stderr

    async def fact_inspect(self, stage, key, cutoff, active, *, closed=False):
        from morgan_brain.composition import build_evidence_context

        ids = [f"fact-{stage}-{key}"]
        if stage and not closed:
            ids.insert(0, f"fact-{stage - 1}-{key}")
        selections = []
        for identity in ids:
            st = int(identity.split("-")[1])
            text = f"synthetic-key-{key} state stage-{st}-{key}"
            selections.append(
                dict(
                    section="current_facts",
                    event_id=identity,
                    start=0,
                    end=len(text),
                    quote=text,
                )
            )
        with guard_inspection(self.counts):
            ctx = build_evidence_context(self.settings)
            try:
                out = await ctx.gate.inspect_context(
                    user_id="synthetic-A",
                    project="personal",
                    evidence_ids=ids,
                    selections=selections,
                    effective_at=cutoff,
                )
            finally:
                ctx.conn.close()
        save(
            self.directory
            / f"fact-inspect-{stage}-{key}-{cutoff.isoformat().replace(':', '_')}.json",
            out,
        )
        require(
            out["requested_ids"] == ids and not out["missing_ids"],
            "PRODUCT factclosure",
        )
        require(
            out["action_authority"] == "none"
            and out["user_id"] == "synthetic-A"
            and out["project"] == "personal",
            "PRODUCT factscopeauthority",
        )
        require(len(canonical(out)) <= 16384, "PRODUCT factcap")
        require(
            [item["event_id"] for item in out["sections"]["current_facts"]["items"]]
            == active,
            "PRODUCT factselected",
        )
        require(
            out["sections"]["current_facts"]["status"]
            == ("unverified" if active else "unknown"),
            "PRODUCT factstatus",
        )
        require(
            out["withheld"]
            == [
                dict(event_id=i, section="current_facts", reason="inactive_interval")
                for i in ids
                if i not in active
            ],
            "PRODUCT factwithheld",
        )
        require([row["id"] for row in out["sources"]] == ids, "PRODUCT factsources")
        for row in out["sources"]:
            st = int(row["id"].split("-")[1])
            require(
                row["content"] == f"synthetic-key-{key} state stage-{st}-{key}"
                and row["source"] == "user_stated"
                and row["author_id"] == "synthetic-A"
                and row["support_state"] == "current"
                and row["support_event_ids"] == ["stable-root"],
                "PRODUCT factprovenance_support",
            )
            require(
                datetime.fromisoformat(row["valid_from"])
                == datetime(2026, 9, 1 + st, tzinfo=UTC),
                "PRODUCT factstart",
            )
            expected_end = (
                datetime(2026, 9, 20, tzinfo=UTC)
                if closed
                else (datetime(2026, 9, 1 + stage, tzinfo=UTC) if st < stage else None)
            )
            require(
                (datetime.fromisoformat(row["valid_to"]) if row["valid_to"] else None)
                == expected_end,
                "PRODUCT factend",
            )
            require(
                row["superseded_by"] == (f"fact-{stage}-{key}" if st < stage else None),
                "PRODUCT factsupersession",
            )
        return out

    def scoped_audit(self):
        from morgan_brain.memory.store.db import open_readonly

        conn = open_readonly(str(self.database))
        result = {}
        try:
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall():
                name = row[0]
                escaped = name.replace('"', '""')
                fields = [r[1] for r in conn.execute(f'PRAGMA table_info("{escaped}")')]
                if "user_id" not in fields or "project" not in fields:
                    continue
                result[name] = {}
                for owner, project in SCOPES:
                    values = [
                        list(r)
                        for r in conn.execute(
                            f'SELECT * FROM "{escaped}" WHERE user_id=? AND project=?',
                            (owner, project),
                        )
                    ]
                    # SQL rows contain binary vectors; encode explicitly for stable digest.
                    rows = [
                        [v.hex() if isinstance(v, bytes) else v for v in r]
                        for r in values
                    ]
                    encoded = sorted(canonical(r) for r in rows)
                    h = hashlib.sha256()
                    for r in encoded:
                        h.update(len(r).to_bytes(8, "big"))
                        h.update(r)
                    result[name][owner + ":" + project] = {
                        "count": len(rows),
                        "sha256": h.hexdigest(),
                    }
            return result
        finally:
            conn.close()

    async def updates(self, stage):
        from morgan_brain.models import TemporalFact

        self.bound()
        times = []
        parent = self.extra[-1]["id"] if self.extra else "update-root"
        for index in range(10):
            raw = event(
                f"extra-{stage}-{index}",
                [parent],
                at=datetime(2026, 9, 1 + stage, tzinfo=UTC) + timedelta(seconds=index),
            )
            times.append(await self.store(raw))
            self.extra.append(raw)
            parent = raw["id"]
        now = datetime(2026, 9, 1 + stage, tzinfo=UTC)
        fact_times = []
        for index in range(10):
            identity = f"fact-{stage}-{index}"
            fact = TemporalFact(
                id=identity,
                user_id="synthetic-A",
                project="personal",
                subject=f"synthetic-key-{index}",
                predicate="state",
                object=f"stage-{stage}-{index}",
                source="user_stated",
                author_id="synthetic-A",
                support_event_ids=["stable-root"],
            )
            start = time.perf_counter()
            await self.writer.gate.upsert_fact(fact, now=now)
            fact_times.append(time.perf_counter() - start)
            save(self.directory / f"fact-update-{stage}-durations.json", fact_times)
            current = await self.writer.gate.current_facts(
                user_id="synthetic-A",
                project="personal",
                subject=fact.subject,
                effective_at=now,
            )
            require([f.id for f in current] == [identity], "PRODUCT factcurrent")
            if stage:
                old = f"fact-{stage - 1}-{index}"
                before = await self.writer.gate.current_facts(
                    user_id="synthetic-A",
                    project="personal",
                    subject=fact.subject,
                    effective_at=now - timedelta(microseconds=1),
                )
                require([f.id for f in before] == [old], "PRODUCT factboundary")
                evidence = await self.writer.gate.evidence(
                    user_id="synthetic-A",
                    project="personal",
                    evidence_ids=[old, identity],
                    effective_at=now,
                )
                require(
                    evidence.records[0].valid_to == now
                    and evidence.records[0].superseded_by == identity
                    and evidence.records[1].valid_from == now,
                    "PRODUCT factinterval",
                )
            await self.fact_inspect(stage, index, now, [identity])
            if stage:
                await self.fact_inspect(
                    stage,
                    index,
                    now - timedelta(microseconds=1),
                    [f"fact-{stage - 1}-{index}"],
                )
            self.facts[index] = identity
        self.bound()
        self.rows[-1]["corrections"] = stats(times)
        self.rows[-1]["fact_updates"] = stats(fact_times)
        self.rows[-1]["post_update_footprint"] = self.footprint()
        save(self.directory / f"stage-{SIZES[stage]}" / "receipt.json", self.rows[-1])

    async def boundary(self, index):
        from morgan_brain.composition import (
            build_evidence_context,
            build_memory_context,
        )
        from morgan_brain.models import Memory

        parent = (
            [
                e["id"]
                for e in self.all_events
                if e["id"].startswith("diary-") and e["revises_event_ids"]
            ][-1]
            if index == 0
            else f"boundary-{index - 1}"
        )
        new = event(
            f"boundary-{index}",
            [parent],
            at=datetime(2026, 9, 25, tzinfo=UTC) + timedelta(seconds=index),
        )
        case, expected = self.case(parent)
        case["requested_ids"] = [parent, new["id"], "chain-root"]
        case["selections"] = []
        expected = self.oracle.inspect(
            user_id="synthetic-A",
            project="personal",
            requested_ids=case["requested_ids"],
            cutoff=CUT.isoformat(),
            selections=[],
        )
        context = build_evidence_context(self.settings)
        ready = threading.Event()
        done = threading.Event()
        trace = []
        failure = []
        seen = False

        def callback(sql):
            nonlocal seen
            if (
                "FROM memories" in sql
                and sql.lstrip().startswith("SELECT")
                and not seen
            ):
                seen = True
                trace.append(
                    {
                        "event": "first_event_SELECT_started",
                        "sql": sql,
                        "at": time.perf_counter(),
                    }
                )
            elif seen and "FROM facts" in sql and not ready.is_set():
                trace.append(
                    {
                        "event": "anchor_completed_pause_before_fact_SELECT",
                        "sql": sql,
                        "at": time.perf_counter(),
                    }
                )
                ready.set()
                if not done.wait(5):
                    failure.append("SETUP boundary wait")

        w = build_memory_context(self.settings)

        def writer():
            try:
                require(ready.wait(5), "SETUP missinganchor")
                try:
                    asyncio.run(w.gate.store(Memory.model_validate(new)))
                finally:
                    w.conn.close()
                trace.append({"event": "writer_committed", "at": time.perf_counter()})
            except Exception as e:
                failure.append(str(e))
            finally:
                done.set()

        context.conn.set_trace_callback(callback)
        thread = threading.Thread(target=writer)
        thread.start()
        try:
            with guard_inspection(self.counts):
                output = await self.inspect(context, case)
        finally:
            context.conn.set_trace_callback(None)
            context.conn.close()
            thread.join(5)
        require(
            not thread.is_alive() and not failure,
            "PRODUCT boundary writer " + str(failure),
        )
        require(ready.is_set(), "SETUP hook notobserved")
        self.refresh_metadata()
        save(
            self.directory / f"boundary-{index}-trace.json",
            {"trace": trace, "failure": failure},
        )
        self.check(case, output, expected)
        self.oracle.admit(new)
        self.all_events.append(new)
        post = self.oracle.inspect(
            user_id="synthetic-A",
            project="personal",
            requested_ids=case["requested_ids"],
            cutoff=CUT.isoformat(),
            selections=[],
        )
        fresh = build_evidence_context(self.settings)
        try:
            with guard_inspection(self.counts):
                after = await self.inspect(fresh, case)
        finally:
            fresh.conn.close()
        self.check(case, after, post)
        save(
            self.directory / f"boundary-{index}.json",
            dict(trace=trace, before=output, after=after, pass_contract=True),
        )
        self.bound()

    def reserve_snapshot(self):
        self.bound()
        disk = sum(p.stat().st_size for p in self.directory.rglob("*") if p.is_file())
        source = sum(
            p.stat().st_size
            for p in (self.database, Path(str(self.database) + "-wal"))
            if p.exists()
        )
        require(disk + source + 96 * 1024**2 <= 768 * 1024**2, "SETUP snapshotreserve")

    async def forget(self):
        with guard_inspection(self.counts):
            await self._forget()

    async def _forget(self):
        from morgan_brain.composition import build_evidence_context
        from morgan_brain.memory import snapshot
        from morgan_brain.memory.store.erasure import StoreInterruptedByForget
        from morgan_brain.models import Memory

        self.bound()
        scoped_before = self.scoped_audit()
        save(self.directory / "forget-before-scopes.json", scoped_before)
        generation = self.writer.gate.capture_erasure_generation()
        counts = []
        self.reserve_snapshot()
        start = time.perf_counter()
        taken = snapshot.take(
            str(self.database),
            into=Path(self.settings.snapshot_dir),
            reason="synthetic-forget",
            clock=lambda: datetime.now(UTC),
        )
        snapshot_seconds = time.perf_counter() - start
        self.bound()
        start = time.perf_counter()
        report = await self.writer.gate.forget(
            user_id="synthetic-A", project="workshop"
        )
        forget_seconds = time.perf_counter() - start
        expected = sum(
            e["user_id"] == "synthetic-A" and e["project"] == "workshop"
            for e in self.all_events
        )
        require(report.memories == expected, "PRODUCT forgetcount")
        try:
            await self.writer.gate.store(
                Memory.model_validate(event("stale-after-forget")),
                expected_generation=generation,
            )
        except StoreInterruptedByForget:
            pass
        else:
            raise RuntimeError("PRODUCT stalegenerationaccepted")
        repeat = await self.writer.gate.forget(
            user_id="synthetic-A", project="workshop"
        )
        require(repeat.memories == 0 and repeat.facts == 0, "PRODUCT repeatforget")
        self.reserve_snapshot()
        start = time.perf_counter()
        raw, stderr = await self.cli(
            ["forget", "--project", "personal", "--json"], owner="synthetic-B"
        )
        cli_seconds = time.perf_counter() - start
        self.bound()
        scoped_after = self.scoped_audit()
        save(self.directory / "forget-after-scopes.json", scoped_after)
        deleted = {"synthetic-A:workshop", "synthetic-B:personal"}
        for table, scopes in scoped_before.items():
            for scope, receipt in scopes.items():
                if scope in deleted:
                    require(
                        scoped_after[table][scope]["count"] == 0,
                        "PRODUCT remaining_scoped_rows " + table,
                    )
                else:
                    require(
                        scoped_after[table][scope] == receipt,
                        "PRODUCT collateral_scoped_rows " + table,
                    )
        (self.directory / "forget-cli.raw").write_bytes(raw)
        (self.directory / "forget-cli.stderr").write_bytes(stderr)
        cli = json.loads(raw)
        expected_cli = sum(
            e["user_id"] == "synthetic-B" and e["project"] == "personal"
            for e in self.all_events
        )
        require(cli["memories"] == expected_cli, "PRODUCT CLI forgetcount")
        for owner, project in [
            ("synthetic-A", "workshop"),
            ("synthetic-B", "personal"),
        ]:
            ids = [
                e["id"]
                for e in self.all_events
                if (e["user_id"], e["project"]) == (owner, project)
            ]
            fresh = build_evidence_context(self.settings)
            try:
                for offset in range(0, len(ids), 16):
                    batch = ids[offset : offset + 16]
                    out = await fresh.gate.inspect_context(
                        user_id=owner,
                        project=project,
                        evidence_ids=batch,
                        effective_at=CUT,
                    )
                    save(
                        self.directory / f"forget-{owner}-{project}-{offset}.json", out
                    )
                    require(
                        out["missing_ids"] == batch and not out["sources"],
                        "PRODUCT forgotsourcesvisible",
                    )
            finally:
                fresh.conn.close()
            counts.append({"scope": [owner, project], "all_missing": len(ids)})
        kept = [
            e
            for e in self.all_events
            if (e["user_id"], e["project"])
            not in [("synthetic-A", "workshop"), ("synthetic-B", "personal")]
        ]
        self.all_events = kept
        self.oracle = Oracle()
        for e in kept:
            self.oracle.admit(e)
        case, expected_case = self.case("boundary-2")
        fresh = build_evidence_context(self.settings)
        try:
            out = await self.inspect(fresh, case)
        finally:
            fresh.conn.close()
        self.check(case, out, expected_case)
        final = self.footprint()
        require(final["counts"]["memories"] == len(kept), "PRODUCT collateralcount")
        save(
            self.directory / "forget.json",
            dict(
                snapshot_seconds=snapshot_seconds,
                snapshot_bytes=taken.path.stat().st_size,
                sdk_seconds=forget_seconds,
                sdk_memories=report.memories,
                cli_seconds=cli_seconds,
                cli=cli,
                samples=counts,
                final=final,
                secure_physical_erasure=False,
            ),
        )
        self.bound()


def finalize(bench, frozen, admitted):
    try:
        end_errors = []
        for filename, sha in frozen.items():
            if digest(Path(filename)) != sha:
                end_errors.append("SETUP end frozen input drift " + filename)
        if time.monotonic() - bench.started >= 1170:
            end_errors.append("SETUP finalization reserve")
        if end_errors:
            admitted = False
            save(
                bench.directory / "integrity-failure.json",
                {"category": "setup_failure", "errors": end_errors},
            )
        save(
            bench.directory / "summary.json",
            dict(
                admitted=admitted,
                fixed_plan={
                    "seeded_checkpoints": list(SIZES),
                    "calls_per_checkpoint": {
                        "sdk": 25,
                        "restart": 5,
                        "cli": 3,
                        "mcp": 3,
                    },
                    "concurrency": 3,
                    "corrections": 40,
                    "fact_upserts": 40,
                },
                rows=bench.rows,
                seeded_store_seconds=stats(bench.times) if bench.times else None,
                seeded_store_count=len(bench.times),
                actual_operations=bench.counts,
                resources=bench.observations,
                phase_seconds=time.monotonic() - bench.started,
                model_calls=0,
                input_tokens=None,
                output_tokens=None,
            ),
        )
        inventory = {
            str(p.relative_to(bench.directory)): digest(p)
            for p in bench.directory.rglob("*")
            if p.is_file()
        }
        save(bench.directory / "export-freeze.json", inventory)
        if end_errors:
            raise RuntimeError("; ".join(end_errors))
    except BaseException as error:
        # Never leave a successful admission when hashing/export/deadline failed.
        summary_path = bench.directory / "summary.json"
        try:
            value = (
                json.loads(summary_path.read_text()) if summary_path.exists() else {}
            )
            value["admitted"] = False
            value["finalization_error"] = str(error)
            save(summary_path, value)
            save(
                bench.directory / "integrity-failure.json",
                {"category": "setup_failure", "error": str(error)},
            )
        finally:
            raise


async def main():
    from morgan_brain.composition import build_memory_context
    from morgan_brain.memory.embedder import FakeEmbedder

    root = Path(__file__).resolve().parent
    frozen = json.loads((root / "input-freeze.json").read_text())
    for filename, sha in frozen.items():
        require(digest(Path(filename)) == sha, "SETUP frozen input drift " + filename)
    directory = root / "baseline"
    directory.mkdir(exist_ok=False)
    bench = Bench(directory)
    original_embed = FakeEmbedder.embed

    async def counted_embed(instance, text):
        bench.counts["hash_embeds"] += 1
        return await original_embed(instance, text)

    admitted = False

    def deadline(signum, frame):
        raise RuntimeError("SETUP absolute phase deadline")

    previous_handler = signal.signal(signal.SIGALRM, deadline)
    signal.setitimer(signal.ITIMER_REAL, 1200)
    try:
        generated = generate()
        validation = Oracle()
        for row in generated:
            try:
                validation.admit(row)
            except Exception as error:
                raise RuntimeError("FIXTURE " + str(error)) from error
        save(
            directory / "fixture-metadata.json",
            dict(
                seeded_rows=len(generated),
                source_bytes=sum(len(e["content"].encode()) for e in generated),
                model_calls=0,
            ),
        )
        save(directory / "fixtures.json", generated)
        bench.bound()
        with (
            patch.object(FakeEmbedder, "embed", counted_embed),
            patch.dict(
                os.environ,
                {
                    k: v
                    for k, v in os.environ.items()
                    if not k.upper().startswith("MORGAN_")
                },
                clear=True,
            ),
            guard_setup(bench.counts),
        ):
            bench.writer = build_memory_context(bench.settings)
            cursor = 0
            for stage, size in enumerate(SIZES):
                while cursor < size:
                    bench.times.append(await bench.store(generated[cursor]))
                    cursor += 1
                    if cursor % 200 == 0:
                        bench.bound()
                        await asyncio.sleep(0)
                bench.bound()
                await bench.reads(size)
                await bench.updates(stage)
            before = await bench.writer.gate.current_facts(
                user_id="synthetic-A",
                project="personal",
                subject="synthetic-key-0",
                effective_at=datetime(2026, 9, 20, tzinfo=UTC)
                - timedelta(microseconds=1),
            )
            require(len(before) == 1, "PRODUCT closebefore")
            await bench.writer.gate.close_fact(
                bench.facts[0],
                user_id="synthetic-A",
                project="personal",
                now=datetime(2026, 9, 20, tzinfo=UTC),
            )
            after = await bench.writer.gate.current_facts(
                user_id="synthetic-A",
                project="personal",
                subject="synthetic-key-0",
                effective_at=datetime(2026, 9, 20, tzinfo=UTC),
            )
            require(not after, "PRODUCT closeboundary")
            await bench.fact_inspect(
                3,
                0,
                datetime(2026, 9, 20, tzinfo=UTC) - timedelta(microseconds=1),
                [bench.facts[0]],
                closed=True,
            )
            await bench.fact_inspect(
                3, 0, datetime(2026, 9, 20, tzinfo=UTC), [], closed=True
            )
            for index in range(3):
                await bench.boundary(index)
            await asyncio.wait_for(
                bench.forget(),
                timeout=min(90, 1200 - (time.monotonic() - bench.started)),
            )
            require(
                bench.counts["network_attempts"] == 0
                and bench.counts["provider_construction_attempts"] == 0,
                "PRODUCT forbiddenattempt",
            )
            admitted = True
    except BaseException as error:
        save(
            directory / "failure.json",
            dict(
                type=type(error).__name__,
                error=str(error),
                category="setup_failure"
                if str(error).startswith("SETUP")
                else (
                    "fixture_failure"
                    if str(error).startswith("FIXTURE")
                    else classify(error)
                ),
            ),
        )
        raise
    finally:
        if bench.writer:
            bench.writer.conn.close()
        try:
            finalize(bench, frozen, admitted)
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            signal.signal(signal.SIGALRM, previous_handler)


if __name__ == "__main__":
    asyncio.run(main())
