"""Independent structural comparison against the pure event reference, without semantics."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any

FIELDS = {
    "id",
    "user_id",
    "project",
    "kind",
    "content",
    "source",
    "author_id",
    "origin_kind",
    "scope",
    "instruction_like",
    "status",
    "created_at",
    "effective_at",
    "recorded_at",
    "revises_event_ids",
    "revision_root_id",
    "revision_state",
    "eligible_leaf_ids",
    "eligible_leaf_count",
    "revision_truncated",
    "support_event_ids",
    "support_state",
    "valid_from",
    "valid_to",
    "superseded_by",
    "last_confirmed",
    "confidence",
}


def canonical(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode()


def same_instant(left: Any, right: Any, *, legacy: bool = False) -> bool:
    if left is None or right is None:
        return left is right
    try:
        a, b = [datetime.fromisoformat(value) for value in (left, right)]
        if a.utcoffset() is None or b.utcoffset() is None:
            if not legacy:
                return False
            a = a.replace(tzinfo=UTC) if a.utcoffset() is None else a
            b = b.replace(tzinfo=UTC) if b.utcoffset() is None else b
        return a == b
    except (ValueError, TypeError):
        return False


def id_set(value: Any) -> set[str] | None:
    if not isinstance(value, list) or any(
        not isinstance(item, str) or not item.strip() for item in value
    ):
        return None
    if len(set(value)) != len(value):
        return None
    return set(value)


def compare(
    case: dict[str, Any],
    envelope: dict[str, Any],
    reference: dict[str, Any],
    seed_metadata: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Return named failed structural checks; never grade usefulness, truth or permission."""
    failures: list[str] = []

    def check(ok: bool, name: str) -> None:
        if not ok:
            failures.append(name)

    try:
        check(isinstance(envelope, dict), "envelope_object")
        check(
            set(envelope)
            == {
                "version",
                "user_id",
                "project",
                "effective_at",
                "requested_ids",
                "missing_ids",
                "coverage",
                "action_authority",
                "sources",
                "sections",
                "withheld",
                "corrections",
                "unresolved_support_ids",
                "unresolved_branch_ids",
                "bounds",
            },
            "envelope_projection",
        )
        check(len(canonical(envelope)) <= 16384, "canonical_utf8_bound")
        check(envelope["version"] == "morgan.continuation_context.v1", "version")
        check(
            envelope["user_id"] == case["user_id"]
            and envelope["project"] == case["project"],
            "owner_project",
        )
        check(
            same_instant(envelope["effective_at"], case["effective_at"]),
            "cutoff_instant",
        )
        check(envelope["requested_ids"] == case["requested_ids"], "requested_order")
        check(envelope["missing_ids"] == reference["missing_ids"], "missing_order")
        check(envelope["coverage"] == "requested_ids_only", "coverage")
        check(envelope["action_authority"] == "none", "authority_none")
        check(
            envelope["bounds"]
            == {
                "source_ids": 16,
                "selections": 16,
                "quote_code_points": 240,
                "serialized_utf8_bytes": 16384,
            },
            "declared_bounds",
        )
        records = reference["records"]
        sources = envelope["sources"]
        check(isinstance(sources, list) and len(sources) <= 16, "source_bounds")
        check(
            [source["id"] for source in sources]
            == [record["id"] for record in records],
            "exact_requested_sources",
        )
        by_id = {record["id"]: record for record in records}
        events = {event["id"]: event for event in case["events"]}
        for source in sources:
            identity = source["id"]
            record, event = by_id[identity], events[identity]
            check(set(source) == FIELDS, "source_projection:" + identity)
            for field in ("id", "content", "source", "author_id", "scope", "status"):
                expected = event.get(field, "stored" if field == "status" else None)
                check(source[field] == expected, "provenance_" + field + ":" + identity)
            check(
                source["user_id"] == case["user_id"]
                and source["project"] == case["project"],
                "source_scope:" + identity,
            )
            check(
                source["kind"] == "episodic"
                and source["origin_kind"] == "unknown"
                and source["instruction_like"] is False,
                "event_metadata:" + identity,
            )
            check(
                same_instant(
                    source["created_at"],
                    event["effective_at"],
                    legacy=case.get("legacy_read", False),
                ),
                "source_created_at:" + identity,
            )
            check(
                same_instant(
                    source["effective_at"],
                    event["effective_at"],
                    legacy=case.get("legacy_read", False),
                ),
                "source_effective_at:" + identity,
            )
            check(
                isinstance(source["recorded_at"], str)
                and same_instant(source["recorded_at"], source["recorded_at"]),
                "recorded_at_present:" + identity,
            )
            check(
                seed_metadata is not None
                and identity in seed_metadata
                and same_instant(source["recorded_at"], seed_metadata[identity]),
                "recorded_at_seed_bound:" + identity,
            )
            for field in (
                "revision_root_id",
                "revision_state",
                "eligible_leaf_count",
                "revision_truncated",
            ):
                check(
                    source[field] == record[field]
                    and type(source[field]) is type(record[field]),
                    field + ":" + identity,
                )
            for field in ("revises_event_ids", "eligible_leaf_ids"):
                check(
                    source[field] == sorted(record[field])
                    and id_set(source[field]) is not None,
                    field + ":" + identity,
                )
            check(
                source["support_event_ids"] == [] and source["support_state"] is None,
                "event_support:" + identity,
            )
            check(
                all(
                    source[field] is None
                    for field in (
                        "valid_from",
                        "valid_to",
                        "superseded_by",
                        "last_confirmed",
                        "confidence",
                    )
                ),
                "event_fact_metadata:" + identity,
            )
        check(
            canonical(envelope["sections"]) == canonical(reference["sections"]),
            "sections_exact_spans_unverified",
        )
        check(envelope["withheld"] == reference["withheld"], "withheld_exact")
        corrections = envelope["corrections"]
        expected_corrections = [
            record for record in records if record["revises_event_ids"]
        ]
        check(
            [item["event_id"] for item in corrections]
            == [record["id"] for record in expected_corrections],
            "correction_ids",
        )
        for item, record in zip(corrections, expected_corrections, strict=True):
            check(
                set(item)
                == {
                    "event_id",
                    "revises_event_ids",
                    "revision_root_id",
                    "revision_state",
                    "eligible_leaf_ids",
                    "eligible_leaf_count",
                    "revision_truncated",
                },
                "correction_fields",
            )
            for field in ("revises_event_ids", "eligible_leaf_ids"):
                check(
                    item[field] == sorted(record[field])
                    and id_set(item[field]) is not None,
                    "correction_" + field,
                )
            for field in (
                "revision_root_id",
                "revision_state",
                "eligible_leaf_count",
                "revision_truncated",
            ):
                check(
                    item[field] == record[field]
                    and type(item[field]) is type(record[field]),
                    "correction_" + field,
                )
        supplied = set(by_id)
        pointers = {
            identity
            for record in records
            for identity in [
                record["revision_root_id"],
                *record["revises_event_ids"],
                *record["eligible_leaf_ids"],
            ]
        } - supplied
        check(
            envelope["unresolved_branch_ids"] == sorted(pointers), "unresolved_branches"
        )
        check(envelope["unresolved_support_ids"] == [], "unresolved_support")
    except (KeyError, TypeError, ValueError, AttributeError, UnicodeError) as error:
        failures.append("malformed_envelope:" + type(error).__name__)
    return {
        "pass": not failures,
        "failures": failures,
        "claim": "explicit_event_structure_only",
    }


def compare_surfaces(envelopes: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """All actual surface envelopes agree, including actual recorded times; no invented clock."""
    failures = []
    if set(envelopes) != {"sdk", "cli", "mcp"}:
        return {"pass": False, "failures": ["three_surfaces_required"]}
    try:
        expected = envelopes["sdk"]
        for name in ("cli", "mcp"):
            candidate = envelopes[name]
            if canonical(candidate) != canonical(expected):
                failures.append("surface_envelope_disagreement:" + name)
    except (TypeError, ValueError, UnicodeError) as error:
        failures.append("malformed_surface:" + type(error).__name__)
    return {"pass": not failures, "failures": failures}
