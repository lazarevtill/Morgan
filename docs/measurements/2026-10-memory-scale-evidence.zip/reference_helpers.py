"""Prospective isolated SDK/CLI/MCP event panel. No model or real-memory access.

Only run after independent comparator/harness review and an explicit frozen fresh fixture.
"""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import os
import socket
import sqlite3
import subprocess
import sys
import time
from contextlib import ExitStack, contextmanager
from pathlib import Path
from unittest.mock import patch

from comparator import canonical, compare, compare_surfaces
from oracle import FixtureInvalid, Oracle

FILE_CAP = 1024 * 1024
ARTIFACT_CAP = 64 * 1024 * 1024


class OutputBound(RuntimeError):
    pass


def write_bounded(path, raw):
    if len(raw) > FILE_CAP:
        path.write_bytes(raw[:FILE_CAP])
        raise OutputBound("physical serialization exceeds1MiB; retained prefix")
    path.write_bytes(raw)


async def capture_child(child, *, timeout=20, cap=FILE_CAP):
    """Bound both pipes while reading concurrently; preserve prefixes on timeout/overflow."""
    buffers = [bytearray(), bytearray()]

    async def drain(stream, buffer):
        while True:
            chunk = await stream.read(65536)
            if not chunk:
                return
            available = cap - len(buffer)
            buffer.extend(chunk[: max(0, available)])
            if len(chunk) > available:
                raise OutputBound("CLI pipe exceeds1MiB; retained prefix")

    tasks = [
        asyncio.create_task(drain(child.stdout, buffers[0])),
        asyncio.create_task(drain(child.stderr, buffers[1])),
        asyncio.create_task(child.wait()),
    ]
    error = None
    try:
        await asyncio.wait_for(asyncio.gather(*tasks), timeout)
    except BaseException as caught:  # noqa: BLE001 - retain partial pipes and kill only owned child
        error = caught
        if child.returncode is None:
            child.kill()
        try:
            await asyncio.wait_for(child.wait(), 1)
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
    return bytes(buffers[0]), bytes(buffers[1]), error


class NetworkAttempt(RuntimeError):
    pass


class ProviderConstructionAttempt(RuntimeError):
    pass


def prevalidate(fixture):
    cases = fixture.get("cases") if isinstance(fixture, dict) else None
    if not isinstance(cases, list) or len(cases) != 16:
        raise FixtureInvalid("fixed16cases", "cases")
    references, invalid = {}, []
    seen = set()
    for index, case in enumerate(cases):
        try:
            case_id = case["case_id"]
            if (
                not isinstance(case_id, str)
                or not case_id.strip()
                or len(case_id) > 256
                or case_id in seen
            ):
                raise FixtureInvalid("case_identity", "case_id")
            seen.add(case_id)
            if (
                len(canonical(case)) > 32768
                or not isinstance(case["events"], list)
                or not 1 <= len(case["events"]) <= 8
                or not isinstance(case["selections"], list)
                or len(case["selections"]) > 6
            ):
                raise FixtureInvalid("fresh_case_bounds", "case")
            if case.get("legacy_read", False):
                raise FixtureInvalid("normal_admissions_only", "legacy_read")
            oracle = Oracle()
            for event in case["events"]:
                if event.get("effective_at") is None:
                    raise FixtureInvalid("explicit_timestamp_required", "effective_at")
                oracle.admit(event)
            references[case_id] = oracle.inspect(
                user_id=case["user_id"],
                project=case["project"],
                requested_ids=case["requested_ids"],
                cutoff=case["effective_at"],
                selections=case["selections"],
            )
        except (FixtureInvalid, KeyError, TypeError, ValueError, UnicodeError) as error:
            invalid.append(
                {
                    "index": index,
                    "category": "fixture_failure",
                    "error": str(error),
                    "code": getattr(error, "code", "malformed_fixture"),
                    "field": getattr(error, "field", "case"),
                }
            )
    return references, invalid


def footprint(database):
    from morgan_brain.memory.store.db import open_readonly

    connection = open_readonly(str(database))
    try:
        schema = [
            list(row)
            for row in connection.execute(
                "SELECT name,sql FROM sqlite_master WHERE type='table' ORDER BY name"
            ).fetchall()
        ]
        counts = {
            name: connection.execute(
                'SELECT COUNT(*) FROM "' + name.replace('"', '""') + '"'
            ).fetchone()[0]
            for name, _ in schema
        }
        return {
            "sha256": hashlib.sha256(database.read_bytes()).hexdigest(),
            "schema": schema,
            "counts": counts,
            "user_version": connection.execute("PRAGMA user_version").fetchone()[0],
        }
    finally:
        connection.close()


def seed_recorded_metadata(database, user_id, project):
    """Independent synthetic-fixture metadata audit; no source content or implicit API closure."""
    from morgan_brain.memory.store.db import open_readonly

    connection = open_readonly(str(database))
    try:
        return {
            row["id"]: row["recorded_at"]
            for row in connection.execute(
                "SELECT id,recorded_at FROM memories WHERE user_id=? AND project=?",
                (user_id, project),
            )
        }
    finally:
        connection.close()


def resources():
    import re
    import resource

    raw = subprocess.run(
        ["/usr/bin/vm_stat"], capture_output=True, text=True, check=True, timeout=2
    ).stdout
    page = int(re.search(r"page size of (\d+) bytes", raw)[1])
    pages = sum(
        int(re.search(r"Pages " + name + r":\s+(\d+)\.", raw)[1])
        for name in ("free", "inactive", "speculative")
    )
    return {
        "reclaimable_ram_bytes": page * pages,
        "rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "vm_stat": raw,
    }


@contextmanager
def guard_setup(counter):
    """Hash setup may construct its offline backend, but may never connect anywhere."""

    def blocked(*args, **kwargs):
        counter["network_attempts"] += 1
        raise NetworkAttempt("synthetic hash setup attempted network")

    with (
        patch.object(socket.socket, "connect", blocked),
        patch.object(socket.socket, "connect_ex", blocked),
    ):
        yield


async def seed_synthetic(
    settings, events, directory, *, build_context=None, memory_type=None
):
    if build_context is None:
        from morgan_brain.composition import build_memory_context
        from morgan_brain.models import Memory

        build_context, memory_type = build_memory_context, Memory.model_validate
    counters = {
        "planned_source_events": len(events),
        "store_attempts": 0,
        "completed_stores": 0,
        "hash_embed_attempts": 0,
        "completed_hash_embeds": 0,
        "network_attempts": 0,
    }
    context = None
    started = time.monotonic()
    try:
        with guard_setup(counters):
            context = build_context(settings)
            original = context.embedder.embed

            async def counted_embed(*args, **kwargs):
                counters["hash_embed_attempts"] += 1
                result = await original(*args, **kwargs)
                counters["completed_hash_embeds"] += 1
                return result

            with patch.object(context.embedder, "embed", counted_embed):
                for event in events:
                    counters["store_attempts"] += 1
                    await context.gate.store(memory_type(event))
                    counters["completed_stores"] += 1
    finally:
        if context is not None:
            context.conn.close()
        counters["seconds"] = time.monotonic() - started
        (directory / "setup-receipt.json").write_bytes(canonical(counters))
    return counters


def envelope_metrics(value, *, physical_bytes=None):
    return {
        "canonical_utf8_bytes": len(canonical(value)),
        "physical_serialization_bytes": physical_bytes,
        "source_count": len(value["sources"]),
        "missing_count": len(value["missing_ids"]),
        "source_content_utf8_bytes": sum(
            len(source["content"].encode()) for source in value["sources"]
        ),
        "section_items": {
            name: len(section["items"]) for name, section in value["sections"].items()
        },
        "section_statuses": {
            name: section["status"] for name, section in value["sections"].items()
        },
        "withheld_count": len(value["withheld"]),
        "unresolved_branch_count": len(value["unresolved_branch_ids"]),
        "unresolved_support_count": len(value["unresolved_support_ids"]),
    }


@contextmanager
def guard_inspection(counter, counter_path=None):
    """Temporary in-process network and model-construction denial after synthetic seeding."""
    from morgan_brain import composition
    from morgan_brain.providers import factory
    from morgan_brain.surfaces.cli import commands

    def blocked_connect(*args, **kwargs):
        counter["network_attempts"] += 1
        raise NetworkAttempt("inspection attempted network")

    def blocked_provider(*args, **kwargs):
        counter["provider_construction_attempts"] += 1
        raise ProviderConstructionAttempt("inspection attempted model construction")

    with ExitStack() as stack:
        stack.enter_context(patch.object(socket.socket, "connect", blocked_connect))
        stack.enter_context(patch.object(socket.socket, "connect_ex", blocked_connect))
        for module in (composition, commands):
            for name in ("build_memory_context", "build_app_context"):
                stack.enter_context(patch.object(module, name, blocked_provider))
        for name, value in vars(factory).items():
            if inspect.isfunction(value) and value.__module__ == factory.__name__:
                stack.enter_context(patch.object(factory, name, blocked_provider))
        try:
            yield
        finally:
            if counter_path is not None:
                counter_path.write_bytes(canonical(counter))


def classify(error):
    if isinstance(error, (NetworkAttempt, ProviderConstructionAttempt)):
        return "product_failure"
    if isinstance(
        error,
        (
            ImportError,
            ModuleNotFoundError,
            subprocess.TimeoutExpired,
            PermissionError,
            TimeoutError,
        ),
    ):
        return "setup_failure"
    if isinstance(error, sqlite3.OperationalError) and (
        "no such module" in str(error) or "unable to open" in str(error)
    ):
        return "setup_failure"
    return "product_failure"


async def execute_case(case, reference, directory, core_path):
    """Actual public API calls; this function is never exercised by pre-freeze unit proofs."""
    from mcp.shared.memory import create_connected_server_and_client_session
    from morgan_brain.composition import build_evidence_context
    from morgan_brain.config import Settings
    from morgan_brain.surfaces.mcp_server import build_server

    database = (directory / "synthetic-db/morgan.db").resolve()
    settings = Settings(
        _env_file=None,
        data_dir=str(database.parent),
        temporal_db_url=f"sqlite:///{database}",
        snapshot_dir=str(directory / "snapshots"),
        owner_user_id=case["user_id"],
        embedding_backend="hash",
        embedding_dim=4,
    )
    counters = {
        "network_attempts": 0,
        "provider_construction_attempts": 0,
        "model_http_calls": 0,
    }
    envelope, comparisons, receipts = {}, {}, {}
    setup = await seed_synthetic(settings, case["events"], directory)
    seed_metadata = seed_recorded_metadata(database, case["user_id"], case["project"])
    (directory / "seed-recorded-metadata.json").write_bytes(canonical(seed_metadata))
    before = footprint(database)
    selections = directory / "selections.json"
    selections.write_bytes(canonical(case["selections"]))
    with guard_inspection(counters, directory / "inspection-counters.json"):
        started = time.monotonic()
        context = build_evidence_context(settings)
        try:
            (directory / "sdk-request.json").write_bytes(
                canonical(
                    {
                        "user_id": case["user_id"],
                        "project": case["project"],
                        "requested_ids": case["requested_ids"],
                        "effective_at": case["effective_at"],
                        "selections": case["selections"],
                    }
                )
            )
            envelope["sdk"] = await context.gate.inspect_context(
                user_id=case["user_id"],
                project=case["project"],
                evidence_ids=case["requested_ids"],
                selections=case["selections"],
                effective_at=__import__("datetime").datetime.fromisoformat(
                    case["effective_at"]
                ),
            )
        finally:
            context.conn.close()
            (directory / "sdk-call-receipt.json").write_bytes(
                canonical(
                    {
                        "seconds": time.monotonic() - started,
                        "before": before,
                        "after": footprint(database),
                    }
                )
            )
        receipts["sdk"] = {
            "seconds": time.monotonic() - started,
            "before": before,
            "after": footprint(database),
        }
        write_bounded(directory / "sdk-envelope.json", canonical(envelope["sdk"]))
        receipts["sdk"]["metrics"] = envelope_metrics(envelope["sdk"])
        (directory / "sdk-receipt.json").write_bytes(canonical(receipts["sdk"]))
        # Fresh context inside each command, so CLI/MCP also prove read-only restart.
        command = [
            sys.executable,
            "-c",
            (
                "import runpy,sys;from panel_runner import guard_inspection; n=[0]; c={'network_attempts':0,'provider_construction_attempts':0};\n"
                "def audit(event,args):\n if event=='socket.connect':\n  n[0]+=1;raise RuntimeError('inspection network forbidden')\n"
                "sys.addaudithook(audit)\ntry:\n with guard_inspection(c):runpy.run_module('morgan_brain.surfaces.cli',run_name='__main__')\n"
                "finally: print('MORGAN_ORACLE_NETWORK_ATTEMPTS='+str(n[0]+c['network_attempts']),file=sys.stderr);print('MORGAN_ORACLE_PROVIDER_ATTEMPTS='+str(c['provider_construction_attempts']),file=sys.stderr)"
            ),
            "context",
            "inspect",
            *case["requested_ids"],
            "--selections",
            str(selections),
            "--effective-at",
            case["effective_at"],
            "--project",
            case["project"],
            "--json",
        ]
        env = {
            key: value
            for key, value in os.environ.items()
            if not key.upper().startswith("MORGAN_")
        }
        env.update(
            PYTHONPATH=str(core_path)
            + os.pathsep
            + str(Path(__file__).resolve().parent),
            XDG_CONFIG_HOME=str(directory / "empty-config"),
            MORGAN_DATA_DIR=settings.data_dir,
            MORGAN_TEMPORAL_DB_URL=settings.temporal_db_url,
            MORGAN_OWNER_USER_ID=case["user_id"],
            MORGAN_EMBEDDING_BACKEND="hash",
        )
        started = time.monotonic()
        (directory / "cli-request.json").write_bytes(canonical({"command": command}))
        child = await asyncio.create_subprocess_exec(
            *command,
            env=env,
            cwd=directory,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr, stream_error = await capture_child(child)
        write_bounded(directory / "cli-stdout.bin", stdout)
        write_bounded(directory / "cli-stderr.bin", stderr)
        receipts["cli"] = {
            "command": command,
            "returncode": child.returncode,
            "seconds": time.monotonic() - started,
            "before": before,
            "after": footprint(database),
            "stdout_bytes": len(stdout),
            "stderr_bytes": len(stderr),
            "stream_error": type(stream_error).__name__ if stream_error else None,
        }
        (directory / "cli-receipt.json").write_bytes(canonical(receipts["cli"]))
        if stream_error is not None:
            raise stream_error
        result = subprocess.CompletedProcess(command, child.returncode, stdout, stderr)
        (directory / "cli-stdout.bin").write_bytes(result.stdout)
        (directory / "cli-stderr.bin").write_bytes(result.stderr)
        if (
            b"MORGAN_ORACLE_NETWORK_ATTEMPTS=0" not in result.stderr
            or b"MORGAN_ORACLE_PROVIDER_ATTEMPTS=0" not in result.stderr
            or result.returncode != 0
        ):
            raise RuntimeError("CLI failure or network guard triggered")
        envelope["cli"] = json.loads(result.stdout)
        write_bounded(directory / "cli-envelope.json", canonical(envelope["cli"]))
        receipts["cli"]["metrics"] = envelope_metrics(
            envelope["cli"], physical_bytes=len(result.stdout)
        )
        (directory / "cli-receipt.json").write_bytes(canonical(receipts["cli"]))
        started = time.monotonic()
        try:
            server = build_server(settings=settings)
            async with create_connected_server_and_client_session(
                server.mcp._mcp_server
            ) as client:
                await client.initialize()
                (directory / "mcp-request.json").write_bytes(
                    canonical(
                        {
                            "tool": "inspect_context",
                            "ids": case["requested_ids"],
                            "project": case["project"],
                            "selections": case["selections"],
                            "effective_at": case["effective_at"],
                        }
                    )
                )
                result = await client.call_tool(
                    "inspect_context",
                    {
                        "ids": case["requested_ids"],
                        "project": case["project"],
                        "selections": case["selections"],
                        "effective_at": case["effective_at"],
                    },
                )
                write_bounded(
                    directory / "mcp-response.json",
                    canonical(result.model_dump(mode="json")),
                )
                if result.isError:
                    raise RuntimeError("MCP public tool error")
                envelope["mcp"] = json.loads(result.content[0].text)
        finally:
            receipts["mcp"] = {
                "seconds": time.monotonic() - started,
                "before": before,
                "after": footprint(database),
            }
            if "mcp" in envelope:
                receipts["mcp"]["metrics"] = envelope_metrics(
                    envelope["mcp"],
                    physical_bytes=(directory / "mcp-response.json").stat().st_size,
                )
            (directory / "mcp-receipt.json").write_bytes(canonical(receipts["mcp"]))
    for name, value in envelope.items():
        (directory / (name + "-envelope.json")).write_bytes(canonical(value))
        receipts[name]["metrics"] = envelope_metrics(
            value,
            physical_bytes=(
                (directory / "cli-stdout.bin").stat().st_size
                if name == "cli"
                else (directory / "mcp-response.json").stat().st_size
                if name == "mcp"
                else None
            ),
        )
        (directory / (name + "-receipt.json")).write_bytes(canonical(receipts[name]))
        comparisons[name] = compare(case, value, reference, seed_metadata=seed_metadata)
        comparisons[name]["read_only"] = (
            receipts[name]["before"] == receipts[name]["after"]
        )
    agreement = compare_surfaces(envelope)
    passed = (
        agreement["pass"]
        and all(item["pass"] and item["read_only"] for item in comparisons.values())
        and not counters["network_attempts"]
        and not counters["provider_construction_attempts"]
    )
    return {
        "category": "pass" if passed else "product_failure",
        "available": True,
        "comparisons": comparisons,
        "agreement": agreement,
        "receipts": receipts,
        "counters": counters,
        "setup": setup,
    }


async def run(
    *,
    fixture_path,
    freeze_path,
    output_directory,
    core_path,
    executor=execute_case,
    probe=resources,
):
    frozen_bytes = freeze_path.read_bytes()
    frozen_hash = hashlib.sha256(frozen_bytes).hexdigest()
    freeze = json.loads(frozen_bytes)

    def verify():
        if hashlib.sha256(freeze_path.read_bytes()).hexdigest() != frozen_hash:
            raise ValueError("freeze changed")
        for filename, expected in freeze["files"].items():
            if hashlib.sha256(Path(filename).read_bytes()).hexdigest() != expected:
                raise ValueError("frozen input/runtime changed")

    verify()
    if str(fixture_path.resolve()) not in freeze["files"]:
        raise ValueError("fixture not frozen")
    fixture = json.loads(fixture_path.read_bytes())
    references, invalid = prevalidate(fixture)
    cases = fixture.get("cases", [])
    output_directory.mkdir(exist_ok=False)
    planned = [
        {
            "index": index,
            "case_id": case.get("case_id") if isinstance(case, dict) else None,
        }
        for index, case in enumerate(cases)
    ]
    (output_directory / "plan.json").write_bytes(canonical(planned))
    rows, stop = [], None
    started = time.monotonic()
    try:
        if invalid:
            stop = "fixture_preflight_invalid"
            for entry in planned:
                error = next(
                    (item for item in invalid if item["index"] == entry["index"]), None
                )
                rows.append(
                    {
                        **entry,
                        "available": False,
                        "category": "fixture_failure"
                        if error
                        else "not_run_fixture_stop",
                        "error": error,
                    }
                )
        else:
            # Standalone only: no ambient MORGAN settings during seeding or inspection.
            with patch.dict(
                os.environ,
                {
                    key: value
                    for key, value in os.environ.items()
                    if not key.upper().startswith("MORGAN_")
                },
                clear=True,
            ):
                for entry, case in zip(planned, cases, strict=True):
                    directory = output_directory / f"case-{entry['index']:02}"
                    directory.mkdir()
                    begin = time.monotonic()
                    row = {**entry, "available": False}
                    try:
                        verify()
                        if stop:
                            raise RuntimeError(stop)
                        observation = probe()
                        row["resources"] = observation
                        if (
                            observation["reclaimable_ram_bytes"] < 2147483648
                            or observation["rss_bytes"] > 1073741824
                        ):
                            stop = "resource_bound"
                            raise TimeoutError(stop)
                        if time.monotonic() - started + 60 > 720:
                            stop = "phase_deadline"
                            raise TimeoutError(stop)
                        if (
                            sum(
                                p.stat().st_size
                                for p in output_directory.rglob("*")
                                if p.is_file() and "synthetic-db" not in p.parts
                            )
                            + 32 * 1024 * 1024
                            > 64 * 1024 * 1024
                        ):
                            stop = "storage_reserve_bound"
                            raise TimeoutError(stop)
                        row.update(
                            await asyncio.wait_for(
                                executor(
                                    case,
                                    references[case["case_id"]],
                                    directory,
                                    core_path,
                                ),
                                60,
                            )
                        )
                    except Exception as error:  # noqa: BLE001 - preserve fixed denominator and original failure
                        row.update(
                            category="not_run_hard_stop"
                            if stop and len(rows)
                            else classify(error),
                            error_type=type(error).__name__,
                            error=str(error),
                        )
                        if classify(error) == "setup_failure":
                            stop = stop or "setup_failure_abort"
                        if isinstance(error, TimeoutError):
                            stop = stop or "case_deadline"
                    finally:
                        try:
                            post = probe()
                            row["post_resources"] = post
                            if (
                                post["rss_bytes"] > 1073741824
                                or post["reclaimable_ram_bytes"] < 2147483648
                            ):
                                row.update(
                                    category="setup_failure",
                                    available=False,
                                    error="post-case resource bound",
                                )
                                stop = "post_case_resource_bound"
                        except Exception as error:  # noqa: BLE001 - keep original rows, fail resource measurement closed
                            row.update(
                                category="setup_failure",
                                available=False,
                                post_resource_error=str(error),
                            )
                            stop = "post_case_resource_probe_failure"
                        row["seconds"] = time.monotonic() - begin
                        rows.append(row)
                        (directory / "receipt.json").write_bytes(canonical(row))
    finally:
        for entry in planned[len(rows) :]:
            rows.append(
                {
                    **entry,
                    "category": "setup_failure",
                    "available": False,
                    "error": "phase interrupted",
                }
            )
        setup_receipts = [
            json.loads(path.read_bytes())
            for path in output_directory.glob("case-*/setup-receipt.json")
        ]
        summary = {
            "version": "morgan.lifecycle.panel.v1",
            "planned": 16,
            "planned_surface_calls": 48,
            "rows": rows,
            "stop_reason": stop,
            "freeze_sha256": frozen_hash,
            "fixture_failure": sum(r["category"] == "fixture_failure" for r in rows),
            "setup_failure": sum(r["category"] == "setup_failure" for r in rows),
            "product_failure": sum(r["category"] == "product_failure" for r in rows),
            "passed": sum(r["category"] == "pass" for r in rows),
            "available": sum(r["available"] for r in rows),
            "not_run": sum(r["category"].startswith("not_run") for r in rows),
            "actual_surface_attempts": sum(
                1
                for name in ("sdk-request.json", "cli-request.json", "mcp-request.json")
                for _ in output_directory.glob("case-*/" + name)
            ),
            "available_surface_outputs": sum(
                1
                for name in (
                    "sdk-envelope.json",
                    "cli-envelope.json",
                    "mcp-envelope.json",
                )
                for _ in output_directory.glob("case-*/" + name)
            ),
            "max_case_seconds": max((row.get("seconds", 0) for row in rows), default=0),
            "model_http_calls": 0,
            "input_tokens": None,
            "output_tokens": None,
            "planned_setup_source_events": sum(len(case["events"]) for case in cases)
            if not invalid
            else 0,
            "completed_setup_stores": sum(
                receipt["completed_stores"] for receipt in setup_receipts
            ),
            "actual_hash_embed_attempts": sum(
                receipt["hash_embed_attempts"] for receipt in setup_receipts
            ),
            "completed_hash_embeds": sum(
                receipt["completed_hash_embeds"] for receipt in setup_receipts
            ),
            "setup_network_attempts": sum(
                receipt["network_attempts"] for receipt in setup_receipts
            ),
            "database_bytes": sum(
                p.stat().st_size
                for p in output_directory.rglob("*")
                if p.is_file() and "synthetic-db" in p.parts
            ),
            "artifact_bytes": sum(
                p.stat().st_size
                for p in output_directory.rglob("*")
                if p.is_file() and "synthetic-db" not in p.parts
            ),
            "inclusive_seconds": time.monotonic() - started,
        }
        try:
            verify()
            summary["runtime_unchanged"] = True
        except (OSError, ValueError) as error:
            summary["runtime_unchanged"] = False
            summary["integrity_error"] = str(error)
        summary["admitted"] = (
            summary["runtime_unchanged"]
            and summary["passed"] == 16
            and summary["available"] == 16
            and not summary["stop_reason"]
            and summary["setup_network_attempts"] == 0
        )
        summary["success"] = summary["admitted"]
        summary_raw = canonical(summary)
        retained = sum(
            p.stat().st_size
            for p in output_directory.rglob("*")
            if p.is_file() and "synthetic-db" not in p.parts
        )
        if retained + len(summary_raw) + 1024 * 1024 > 64 * 1024 * 1024:
            raise RuntimeError("terminal artifact storage bound")
        (output_directory / "summary.json").write_bytes(summary_raw)
        inventory = {
            str(path.relative_to(output_directory)): hashlib.sha256(
                path.read_bytes()
            ).hexdigest()
            for path in sorted(output_directory.rglob("*"))
            if path.is_file()
        }
        (output_directory / "export-freeze.json").write_bytes(
            canonical({"files": inventory})
        )
    return summary
