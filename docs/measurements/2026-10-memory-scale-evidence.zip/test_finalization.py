"""Pure fault injection; no Morgan dispatch, models or database."""
import json
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import scale_runner


class Finalization(unittest.TestCase):
    def check_failure(self, error):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            bench = SimpleNamespace(directory=directory, started=time.monotonic(), rows=[], times=[], counts={}, observations=[])
            with patch.object(scale_runner, 'digest', side_effect=error):
                with self.assertRaises(type(error)):
                    scale_runner.finalize(bench, {}, True)
            result = json.loads((directory/'summary.json').read_text())
            self.assertFalse(result['admitted'])
            self.assertTrue((directory/'integrity-failure.json').exists())
            self.assertFalse((directory/'export-freeze.json').exists())

    def test_hash_failure_after_success_summary(self):
        self.check_failure(OSError('mock hash failure'))

    def test_deadline_after_success_summary(self):
        self.check_failure(RuntimeError('SETUP absolute phase deadline'))

    def test_missing_frozen_source_before_summary(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            bench = SimpleNamespace(directory=directory, started=time.monotonic(), rows=[], times=[], counts={}, observations=[])
            with self.assertRaises(FileNotFoundError):
                scale_runner.finalize(bench, {str(directory/'missing.py'):'none'}, True)
            self.assertFalse(json.loads((directory/'summary.json').read_text())['admitted'])

if __name__ == '__main__':
    unittest.main()
