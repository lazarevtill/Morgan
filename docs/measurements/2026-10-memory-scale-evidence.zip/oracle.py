"""Independent explicit-event lifecycle state machine; standard library only.

No production imports, SQL, semantic interpretation, discovery, fact support or answer scoring.
Suppression is retained from every activated stored child, including historical nonleaves.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any


class FixtureInvalid(ValueError):
    """Malformed fixture/admission, separate from an expected inactive lifecycle state."""

    def __init__(self, code: str, field: str, event_id: str | None = None):
        self.code, self.field, self.event_id = code, field, event_id
        super().__init__(f"{code}:{field}" + (f":{event_id}" if event_id else ""))


def identity(value: Any, field: str, event_id: str | None = None) -> str:
    if (
        not isinstance(value, str)
        or not value.strip()
        or (
            field in {"id", "requested_ids", "revises_event_ids", "event_id"}
            and len(value) > 256
        )
    ):
        raise FixtureInvalid("nonblank_identity_required", field, event_id)
    return value


def instant(value: Any, *, field: str, legacy_read: bool = False) -> datetime:
    if not isinstance(value, (str, datetime)):
        raise FixtureInvalid("timestamp_required", field)
    try:
        parsed = datetime.fromisoformat(value) if isinstance(value, str) else value
    except ValueError as error:
        raise FixtureInvalid("invalid_timestamp", field) from error
    if parsed.utcoffset() is None:
        if not legacy_read:
            raise FixtureInvalid("aware_timestamp_required", field)
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


@dataclass(frozen=True)
class Event:
    id: str
    user_id: str
    project: str
    source: str
    author_id: str
    scope: str
    effective_at: datetime | None
    raw_effective_at: str | None
    content: str
    status: str
    parents: tuple[str, ...]
    root_id: str
    kind: str = "episodic"


class Oracle:
    """Admit immutable explicit events, then inspect only requested IDs in one scope."""

    def __init__(self) -> None:
        self._events: dict[str, Event] = {}

    def admit(self, raw: dict[str, Any], *, legacy_read: bool = False) -> Event:
        if type(legacy_read) is not bool:
            raise FixtureInvalid("legacy_mode_boolean", "legacy_read")
        if not isinstance(raw, dict):
            raise FixtureInvalid("object_required", "event")
        required = {
            "id",
            "user_id",
            "project",
            "source",
            "author_id",
            "scope",
            "effective_at",
            "revises_event_ids",
            "content",
        }
        if not required <= set(raw) or set(raw) - (
            required | {"kind", "status", "revision_root_id"}
        ):
            raise FixtureInvalid("event_fields", "event")
        event_id = identity(raw["id"], "id")
        if event_id in self._events:
            raise FixtureInvalid("duplicate_event", "id", event_id)
        user = identity(raw["user_id"], "user_id", event_id)
        project = identity(raw["project"], "project", event_id)
        content = raw["content"]
        if not isinstance(content, str) or not content.strip():
            raise FixtureInvalid("nonblank_content_required", "content", event_id)
        source = raw["source"]
        if not isinstance(source, str) or source not in {
            "user_stated",
            "agent_inferred",
            "tool_observed",
            "unknown",
        }:
            raise FixtureInvalid("invalid_source", "source", event_id)
        author = raw["author_id"]
        if not isinstance(author, str):
            raise FixtureInvalid("invalid_author", "author_id", event_id)
        scope = raw["scope"]
        if not isinstance(scope, str) or scope not in {"private", "shared"}:
            raise FixtureInvalid("invalid_scope", "scope", event_id)
        status = raw.get("status", "stored")
        if not isinstance(status, str) or status not in {"stored", "quarantined"}:
            raise FixtureInvalid("invalid_status", "status", event_id)
        if raw.get("kind", "episodic") != "episodic":
            raise FixtureInvalid("event_only", "kind", event_id)
        at = (
            None
            if raw["effective_at"] is None
            else instant(
                raw["effective_at"], field="effective_at", legacy_read=legacy_read
            )
        )
        raw_at = (
            raw["effective_at"].isoformat()
            if isinstance(raw["effective_at"], datetime)
            else raw["effective_at"]
        )
        parents = raw["revises_event_ids"]
        if not isinstance(parents, list) or len(parents) > 8:
            raise FixtureInvalid("parent_bounds", "revises_event_ids", event_id)
        for parent in parents:
            identity(parent, "revises_event_ids", event_id)
        if len(set(parents)) != len(parents):
            raise FixtureInvalid("duplicate_parent", "revises_event_ids", event_id)
        root = event_id
        if parents:
            if source == "unknown" or not author.strip():
                raise FixtureInvalid(
                    "known_actor_required", "source/author_id", event_id
                )
            roots = set()
            for parent_id in parents:
                parent = self._events.get(parent_id)
                if parent is None:
                    raise FixtureInvalid(
                        "missing_parent", "revises_event_ids", event_id
                    )
                if parent.status != "stored" or parent.kind != "episodic":
                    raise FixtureInvalid(
                        "stored_event_parent_required", "revises_event_ids", event_id
                    )
                if (
                    parent.user_id,
                    parent.project,
                    parent.source,
                    parent.author_id,
                    parent.scope,
                ) != (user, project, source, author, scope):
                    raise FixtureInvalid(
                        "parent_boundary",
                        "user_id/project/source/author_id/scope",
                        event_id,
                    )
                if parent.effective_at is None or at is None:
                    raise FixtureInvalid(
                        "dated_correction_required", "effective_at", event_id
                    )
                if parent.effective_at > at:
                    raise FixtureInvalid("parent_after_child", "effective_at", event_id)
                roots.add(parent.root_id)
            if len(roots) != 1:
                raise FixtureInvalid("cross_root_merge", "revises_event_ids", event_id)
            root = roots.pop()
        if raw.get("revision_root_id") is not None and raw["revision_root_id"] != root:
            raise FixtureInvalid("derived_root_mismatch", "revision_root_id", event_id)
        event = Event(
            event_id,
            user,
            project,
            source,
            author,
            scope,
            at,
            raw_at,
            content,
            status,
            tuple(parents),
            root,
        )
        self._events[event_id] = event
        return event

    def snapshot(
        self,
        *,
        user_id: str,
        project: str,
        requested_ids: list[str],
        cutoff: str | datetime,
    ) -> dict[str, Any]:
        user_id = identity(user_id, "user_id")
        project = identity(project, "project")
        at = instant(cutoff, field="cutoff")
        if not isinstance(requested_ids, list) or not 1 <= len(requested_ids) <= 16:
            raise FixtureInvalid("requested_bounds", "requested_ids")
        for event_id in requested_ids:
            identity(event_id, "requested_ids")
        if len(set(requested_ids)) != len(requested_ids):
            raise FixtureInvalid("duplicate_requested", "requested_ids")
        scoped = {
            key: value
            for key, value in self._events.items()
            if (value.user_id, value.project) == (user_id, project)
        }
        activated = {
            key
            for key, event in scoped.items()
            if event.status == "stored"
            and (event.effective_at is None or event.effective_at <= at)
        }
        # Include ALL activated children, not just the current leaves: no ancestor resurrection.
        suppressed = {parent for key in activated for parent in scoped[key].parents}
        leaves = activated - suppressed
        family_leaves: dict[str, list[str]] = {}
        for event_id in leaves:
            family_leaves.setdefault(scoped[event_id].root_id, []).append(event_id)
        for ids in family_leaves.values():
            ids.sort()
        results, missing = [], []
        for event_id in requested_ids:
            event = scoped.get(event_id)
            if event is None:
                missing.append(event_id)
                continue
            eligible = family_leaves.get(event.root_id, [])
            state = (
                "inactive"
                if event_id not in leaves
                else "conflicted"
                if len(eligible) > 1
                else "active"
            )
            results.append(
                {
                    "id": event_id,
                    "content": event.content,
                    "source": event.source,
                    "author_id": event.author_id,
                    "scope": event.scope,
                    "status": event.status,
                    "effective_at": event.raw_effective_at,
                    "revision_root_id": event.root_id,
                    "revision_state": state,
                    "revises_event_ids": list(event.parents),
                    "eligible_leaf_ids": eligible[:32],
                    "eligible_leaf_count": len(eligible),
                    "revision_truncated": len(eligible) > 32,
                }
            )
        return {
            "version": "morgan.lifecycle_oracle.v1",
            "user_id": user_id,
            "project": project,
            "effective_at": at.isoformat(),
            "requested_ids": list(requested_ids),
            "missing_ids": missing,
            "coverage": "requested_ids_only",
            "records": results,
        }

    def inspect(
        self,
        *,
        user_id: str,
        project: str,
        requested_ids: list[str],
        cutoff: str | datetime,
        selections: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Structural eligibility of exact explicit spans; semantic categories stay unverified."""
        result = self.snapshot(
            user_id=user_id, project=project, requested_ids=requested_ids, cutoff=cutoff
        )
        names = (
            "current_facts",
            "completed_progress",
            "unresolved_questions",
            "relevant_constraints",
        )
        proposed = [] if selections is None else selections
        if not isinstance(proposed, list) or len(proposed) > 16:
            raise FixtureInvalid("selection_bounds", "selections")
        seen = set()
        for item in proposed:
            if not isinstance(item, dict) or set(item) != {
                "section",
                "event_id",
                "start",
                "end",
                "quote",
            }:
                raise FixtureInvalid("selection_fields", "selections")
            if not isinstance(item["section"], str) or item["section"] not in names:
                raise FixtureInvalid("selection_section", "section")
            event_id = identity(item["event_id"], "event_id")
            if event_id not in requested_ids:
                raise FixtureInvalid("selection_not_requested", "event_id", event_id)
            start, end, quote = item["start"], item["end"], item["quote"]
            if type(start) is not int or type(end) is not int or not 0 <= start < end:
                raise FixtureInvalid("selection_offsets", "start/end", event_id)
            if (
                not isinstance(quote, str)
                or not quote.strip()
                or not 1 <= len(quote) <= 240
                or end - start != len(quote)
            ):
                raise FixtureInvalid("selection_quote", "quote", event_id)
            span = (event_id, start, end)
            if span in seen:
                raise FixtureInvalid("duplicate_span", "selections", event_id)
            seen.add(span)
        records = {record["id"]: record for record in result["records"]}
        sections = {name: {"status": "unknown", "items": []} for name in names}
        withheld = []
        for item in proposed:
            record = records.get(item["event_id"])
            reason = None
            if record is None:
                reason = "missing"
            else:
                if record["content"][item["start"] : item["end"]] != item[
                    "quote"
                ] or item["end"] > len(record["content"]):
                    raise FixtureInvalid("quote_mismatch", "quote", item["event_id"])
                if record["status"] == "quarantined":
                    reason = "quarantined"
                elif (
                    record["revision_truncated"]
                    or record["revision_state"] == "conflicted"
                ):
                    reason = "conflicted_or_truncated_lineage"
                elif record["revision_state"] == "inactive":
                    reason = "inactive_or_future"
            section = sections[item["section"]]
            if reason:
                withheld.append(
                    {
                        "event_id": item["event_id"],
                        "section": item["section"],
                        "reason": reason,
                    }
                )
                if reason == "conflicted_or_truncated_lineage":
                    section["status"] = "contested"
            else:
                accepted = dict(item, classification="unverified_selection")
                if item["section"] == "completed_progress":
                    accepted["verification"] = "unverified_report"
                section["items"].append(accepted)
                if section["status"] != "contested":
                    section["status"] = "unverified"
        result.update(sections=sections, withheld=withheld, action_authority="none")
        return result
